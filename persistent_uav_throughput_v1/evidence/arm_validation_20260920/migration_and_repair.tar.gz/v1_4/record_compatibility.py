"""Append audited ARM v1.4 compatibility, preserving all prior records."""
import ast, json, os, subprocess, sys
from pathlib import Path
OUT=Path(__file__).resolve().parent
WORK=OUT.parent.parent
ROOT=WORK/'repo'
PROJECT=ROOT/'persistent_uav_throughput_v1'
os.environ['PERSISTENT_UAV_LEGACY_ROOT']=str(ROOT)
sys.path.insert(0,str(PROJECT))
from persistent_uav.provenance import provenance, verify_provenance
from persistent_uav.storage import sha
from persistent_uav.evaluation import calibration_compatibility
from review_bundle.safety.collision.hocbf import _NATIVE_QP_FUNCTION
old_path=OUT.parent/'calibration_compatibility_arm64.json'
old=json.loads(old_path.read_text())
local_path=PROJECT/'evidence/v1_4/calibration_compatibility.json'
local=json.loads(local_path.read_text())
current=provenance()
assert current['sources']=={str(ROOT/Path(k).relative_to('/home/zjl/mappo')):v for k,v in local['diagnostic_provenance']['sources'].items()}
for k in current.keys()-{'sources'}:
    assert current[k]==old['diagnostic_provenance'][k], k
changed={str(Path(k).relative_to(PROJECT)):dict(before=old['diagnostic_provenance']['sources'][k],after=v) for k,v in current['sources'].items() if v!=old['diagnostic_provenance']['sources'][k]}
assert changed==local['changed_since_v1_3']
assert set(changed)=={'persistent_uav/navigation.py','persistent_uav/evaluation.py'}
def nonstationary(source):
    tree=ast.parse(source)
    for node in tree.body:
        if isinstance(node,ast.ClassDef) and node.name=='FrozenNavigator':
            node.body=[n for n in node.body if not(isinstance(n,ast.FunctionDef) and n.name=='advance_stationary')]
    return ast.dump(tree)
before=subprocess.check_output(['git','-C',str(ROOT),'show','a5ea296:persistent_uav_throughput_v1/persistent_uav/navigation.py'],text=True)
assert nonstationary(before)==nonstationary((PROJECT/'persistent_uav/navigation.py').read_text())
for name,digest in json.loads((OUT.parent/'migration.json').read_text())['historical_evidence_hashes'].items():
    assert sha(PROJECT/name)==digest
assert _NATIVE_QP_FUNCTION is not None
assert sha(ROOT/'runtime_support/review_bundle/safety/collision/_qp_native.so')==old['native']['arm64_binary_sha256']
assert sha(ROOT/'runtime_support/review_bundle/safety/collision/_qp_native.c')==old['native']['source_sha256']
frozen_path=PROJECT/'evidence/v1_2/calibration/frozen_regimes.json'
frozen=json.loads(frozen_path.read_text())
assert sha(frozen_path)==old['calibration_sha256']==local['calibration_sha256']
assert frozen['provenance']==old['calibration_provenance']==local['calibration_provenance']
assert len(frozen['regimes'])==27
smoke=json.loads((OUT/'continuing_smoke/recovery_equivalence.json').read_text())
assert smoke['passed'] and smoke['restored_outcome_equal']
tests=(OUT/'tests.txt').read_text()
assert 'Ran 34 tests' in tests and tests.rstrip().endswith('OK')
record=dict(old)
record.update(reason='v1.4 stationary-grid roundoff and failure-status repair, audited on migrated ARM CPU runtime.',diagnostic_provenance=current,repository_commit=subprocess.check_output(['git','-C',str(ROOT),'rev-parse','HEAD'],text=True).strip(),prior_arm_compatibility=dict(path=str(old_path),sha256=sha(old_path)),local_repair_compatibility=dict(path=str(local_path),sha256=sha(local_path)),changed_since_prior_arm=changed,checks=dict(all_104_sources_match_repair_manifest=True,flight_code_unchanged=True,model_hash_match=True,native_source_and_arm_binary_unchanged=True,native_loaded=True,historical_evidence_unchanged=True,tests_34_passed=True,continuing_smoke_passed=True),limits='Full fresh ARM B4 validation only: original 27 regimes, 4 thresholds, 10 seeds. Never import local 382 rows or checkpoint. First checkpoint health then hand back; no automatic evaluation, training or Oracle. No cross-platform bitwise equivalence claim.')
path=OUT/'calibration_compatibility_arm64.json'
path.write_text(json.dumps(record,indent=2)+'\n')
assert calibration_compatibility(frozen_path,frozen,path)==record
for historical in (old['diagnostic_provenance'],local['diagnostic_provenance']):
    try: verify_provenance(historical)
    except RuntimeError: pass
    else: raise AssertionError('Stale or foreign provenance accepted')
print('ARM v1.4 compatibility verified; old/foreign provenance rejected.')
