# ARM B4 validation running

Repository synchronized to 5bf3025. uv environment, ARM solver and all prior migration records preserved. New compatibility: calibration_compatibility_arm64.json, chained to prior ARM and upstream v1.4 records. Historical calibration, frozen regimes and model are unchanged.

34 tests and one continuing smoke passed, including wait-grid regression and full midflight recovery outcome equality. No cross-platform checkpoint replay or local 382-row import.

PID: 447916

Output: `/mnt/workspace/persistent-uav/repo/persistent_uav_throughput_v1/artifacts/diagnostic_validation_arm64_v1_4_20260920`

Log: `/mnt/workspace/persistent-uav/repo/persistent_uav_throughput_v1/artifacts/diagnostic_validation_arm64_v1_4_20260920.log`

Startup health passed: original 27 × 4 × 10 = 1080 validation jobs; valid snapshot checksum, deserialization, contract and provenance; native solver loaded; training updates and oracle calls zero. First checkpoint logged at 100 steps. The process had reached 1500 steps and 1 completed run at the single checkpoint inspection; health evidence captures that snapshot. Process remains running, with no further monitoring or automatic evaluation.

To pause, verify PID and command still match launch.json, then:

```bash
kill -TERM 447916
```

Resume only after it has stopped, using this single-line command:

```bash
cd /mnt/workspace/persistent-uav/repo/persistent_uav_throughput_v1 && source /mnt/workspace/persistent-uav/migration_20260920/env.sh && /mnt/workspace/persistent-uav/.venv/bin/python -u -m persistent_uav.cli baselines --frozen /mnt/workspace/persistent-uav/repo/persistent_uav_throughput_v1/evidence/v1_2/calibration/frozen_regimes.json --calibration-compatibility /mnt/workspace/persistent-uav/migration_20260920/v1_4/calibration_compatibility_arm64.json --output /mnt/workspace/persistent-uav/repo/persistent_uav_throughput_v1/artifacts/diagnostic_validation_arm64_v1_4_20260920 --split validation --regimes all --checkpoint-policy-steps 100 --resume
```

Do not modify runtime source or dependencies while the run is active. Do not merge the original server's 382 historical rows. No calibration rerun, evaluation, neural training, MPC/Oracle or final kill test was launched.
