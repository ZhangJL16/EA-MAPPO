import hashlib,itertools,json,os,pickle,sys,time
from pathlib import Path
A=Path(__file__).resolve().parent
launch=json.loads((A/'launch.json').read_text());out=Path(launch['output']);root=A.parent.parent/'repo'
os.environ.update(launch['environment_overrides']);sys.path.insert(0,launch['cwd'])
from persistent_uav.provenance import verify_provenance
from persistent_uav.config import VALIDATION_SEEDS, THRESHOLDS
from review_bundle.safety.collision.hocbf import _NATIVE_QP_FUNCTION
for _ in range(60):
    if (out/'error.json').exists(): raise RuntimeError((out/'error.json').read_text())
    os.kill(launch['pid'],0)
    if (out/'status.json').exists(): break
    time.sleep(.5)
else: raise RuntimeError('No first checkpoint yet')
status=json.loads((out/'status.json').read_text());ref=status['snapshot']
raw=(out/ref['file']).read_bytes();assert hashlib.sha256(raw).hexdigest()==ref['sha256']
state=pickle.loads(raw);manifest=json.loads((out/'manifest.json').read_text())
verify_provenance(manifest['provenance']);assert state['contract']==manifest
expected=[dict(regime=r,method='threshold_sjf',threshold=t,seed=s) for r,t,s in itertools.product(range(27),THRESHOLDS,VALIDATION_SEEDS)]
assert manifest['jobs']==expected and len(expected)==1080
assert manifest['dataset_seeds']==list(VALIDATION_SEEDS) and manifest['split']=='validation'
assert status['status']=='running' and status['training_updates']==0 and manifest['oracle_calls']==0
assert state['total_policy_steps']==status['total_policy_steps'] and state['total_policy_steps']>=100
assert len(state['rows'])==status['completed_runs']
assert _NATIVE_QP_FUNCTION is not None
assert manifest['calibration_compatibility']==json.loads((A/'calibration_compatibility_arm64.json').read_text())
cmd=Path(f"/proc/{launch['pid']}/cmdline").read_bytes().split(b'\0')
assert [x.decode() for x in cmd if x]==launch['command']
health=dict(passed=True,pid=launch['pid'],checked_unix=time.time(),status=status,checkpoint_checksum_valid=True,checkpoint_deserialized=True,checkpoint_contract_matches_manifest=True,current_provenance_verified=True,all_1080_original_jobs_verified=True,native_loaded=True,old_rows_imported=0,env_observation=state['env'].observe() if state['env'] else None,notes='Read-only startup check; no production pause/resume, extra rollout, or monitoring to completion.')
(A/'startup_health.json').write_text(json.dumps(health,indent=2)+'\n')
print(json.dumps({k:v for k,v in health.items() if k!='env_observation'}))
