"""Audited CPU sharding around unchanged evaluation.run; no automatic next stage."""
import argparse
import copy
import itertools
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time

HERE = Path(__file__).resolve().parent
WORK = HERE.parent.parent
PROJECT = WORK / 'repo/persistent_uav_throughput_v1'
os.environ['PERSISTENT_UAV_LEGACY_ROOT'] = str(WORK / 'repo')
sys.path.insert(0, str(PROJECT))
from persistent_uav.config import THRESHOLDS, VALIDATION_SEEDS
from persistent_uav.evaluation import aggregate, choose_thresholds, calibration_compatibility
from persistent_uav.provenance import verify_provenance
from persistent_uav.storage import exclusive_run, restore, sha, snapshot, write_json

FIELDS = ('regime', 'method', 'threshold', 'seed')
THREAD_ENV = dict(OPENBLAS_NUM_THREADS='1', OMP_NUM_THREADS='1', MKL_NUM_THREADS='1',
                  NUMEXPR_NUM_THREADS='1', VECLIB_MAXIMUM_THREADS='1', BLIS_NUM_THREADS='1',
                  CUDA_VISIBLE_DEVICES='', ASCEND_RT_VISIBLE_DEVICES='')


def key(row):
    return tuple(row[k] for k in FIELDS)


def expected_jobs():
    return [dict(regime=r, method='threshold_sjf', threshold=t, seed=s)
            for r, t, s in itertools.product(range(27), THRESHOLDS, VALIDATION_SEEDS)]


def partition(state, workers):
    if not 1 <= workers <= 27:
        raise ValueError('worker count must be between 1 and 27')
    contract = state['contract']
    jobs, rows = contract['jobs'], state['rows']
    if jobs != expected_jobs() or contract['split'] != 'validation':
        raise ValueError('requires original complete 1080-job validation contract')
    if len(rows) > len(jobs) or [key(r) for r in rows] != [key(j) for j in jobs[:len(rows)]]:
        raise ValueError('completed rows are not the exact job prefix')
    if len(rows) == len(jobs) and state['env'] is not None:
        raise ValueError('completed source unexpectedly has active environment')
    owner = jobs[len(rows)]['regime'] % workers if state['env'] is not None else None
    shards = []
    for i in range(workers):
        regimes = list(range(i, 27, workers))
        sub = copy.deepcopy(contract)
        sub.update(regimes=regimes, jobs=[j for j in jobs if j['regime'] in regimes])
        selected = [r for r in rows if r['regime'] in regimes]
        assert [key(r) for r in selected] == [key(j) for j in sub['jobs'][:len(selected)]]
        # Counters are execution bookkeeping, not scientific metrics. Preserve the
        # original global count once; other workers start their new-work count at 0.
        carry_counter = i == (owner if owner is not None else 0)
        shards.append(dict(contract=sub, rows=selected,
                           env=state['env'] if i == owner else None,
                           total_policy_steps=state['total_policy_steps'] if carry_counter else 0))
    assert sorted(key(j) for s in shards for j in s['contract']['jobs']) == sorted(key(j) for j in jobs)
    assert sum(s['total_policy_steps'] for s in shards) == state['total_policy_steps']
    return shards


def checked_rows(jobs, rows):
    expected = [key(j) for j in jobs]
    actual = [key(r) for r in rows]
    if len(actual) != len(set(actual)):
        raise ValueError('duplicate job IDs')
    if set(actual) != set(expected) or len(actual) != len(expected):
        raise ValueError('missing or unexpected job IDs')
    lookup = {key(r): r for r in rows}
    return [lookup[k] for k in expected]


def verify_plan(output):
    plan = json.loads((output / 'sharding_manifest.json').read_text())
    assert sha(Path(__file__)) == plan['orchestrator_sha256'], 'orchestrator changed'
    verify_provenance(plan['source_contract']['provenance'])
    native = WORK / 'repo/runtime_support/review_bundle/safety/collision/_qp_native.so'
    assert sha(native) == plan['arm_native_sha256']
    compatibility = Path(plan['compatibility'])
    assert sha(compatibility) == plan['compatibility_sha256']
    frozen = Path(plan['frozen'])
    calibration_compatibility(frozen, json.loads(frozen.read_text()), compatibility)
    return plan


def prepare(source, output, workers):
    source, output = source.resolve(), output.resolve()
    if output.exists():
        raise FileExistsError('new parallel output must not exist')
    with exclusive_run(source):
        status = json.loads((source / 'status.json').read_text())
        assert status['status'] == 'paused'
        state = restore(source)
        assert state['contract'] == json.loads((source / 'manifest.json').read_text())
        verify_provenance(state['contract']['provenance'])
        assert len(state['rows']) == status['completed_runs']
        shards = partition(state, workers)
        old_launch = json.loads((HERE.parent / 'v1_4/launch.json').read_text())
        compatibility = Path(old_launch['command'][old_launch['command'].index('--calibration-compatibility')+1])
        frozen = PROJECT / 'evidence/v1_2/calibration/frozen_regimes.json'
        calibration_compatibility(frozen, json.loads(frozen.read_text()), compatibility)
        output.mkdir(parents=True)
        plan = dict(kind='ARM_CPU_VALIDATION_SHARD_MIGRATION', workers=workers,
                    source=str(source), source_contract=state['contract'],
                    source_manifest_sha256=sha(source/'manifest.json'),
                    source_resume=json.loads((source/'resume.json').read_text()),
                    source_completed_rows=len(state['rows']), source_policy_steps=state['total_policy_steps'],
                    frozen=str(frozen), compatibility=str(compatibility),
                    compatibility_sha256=sha(compatibility), orchestrator_sha256=sha(Path(__file__)),
                    arm_native_sha256=sha(WORK/'repo/runtime_support/review_bundle/safety/collision/_qp_native.so'),
                    thread_environment=THREAD_ENV, old_x86_rows_imported=0,
                    policy='regime ID modulo worker count; independent process/checkpoint; exact 1080-job union',
                    created_unix=time.time(), shards=[])
        for i, sub in enumerate(shards):
            folder=output/f'worker_{i:02d}';folder.mkdir()
            write_json(folder/'manifest.json',sub['contract'])
            ref=snapshot(folder,sub)
            write_json(folder/'status.json',dict(status='paused',completed_runs=len(sub['rows']),
                       planned_runs=len(sub['contract']['jobs']),total_policy_steps=sub['total_policy_steps'],
                       snapshot=ref,checkpoint_written_unix=time.time(),training_updates=0))
            for n,row in enumerate(sub['rows']):
                index=next(k for k,j in enumerate(state['contract']['jobs']) if key(j)==key(row))
                original=source/f'run_{index:05d}.json'
                assert json.loads(original.read_text())['summary']==row
                shutil.copy2(original,folder/f'run_{n:05d}.json')
            for stream in source.glob('stream_*.json'):
                if int(stream.name.split('_')[1][1:]) in sub['contract']['regimes']:
                    shutil.copy2(stream,folder/stream.name)
            restored=restore(folder)
            assert restored['contract']==sub['contract'] and restored['rows']==sub['rows']
            if sub['env'] is not None:
                assert restored['env'].observe()==state['env'].observe()
                assert restored['env'].summary()==state['env'].summary()
                assert restored['env'].events==state['env'].events
            plan['shards'].append(dict(worker=i,output=str(folder),regimes=sub['contract']['regimes'],
                jobs=len(sub['contract']['jobs']),initial_rows=len(sub['rows']),
                initial_steps=sub['total_policy_steps'],carries_live_environment=sub['env'] is not None,
                manifest_sha256=sha(folder/'manifest.json'),initial_snapshot=ref))
        write_json(output/'sharding_manifest.json',plan)
        assert json.loads((source/'resume.json').read_text())==plan['source_resume']
        write_json(HERE/'migration_check.json',dict(passed=True,source_unchanged=True,
            original_jobs=1080,workers=workers,preserved_arm_rows=len(state['rows']),
            preserved_inflight_environment=state['env'] is not None,
            disjoint_jobs=True,complete_union=True,serialized_shards_verified=True))
    print(json.dumps(dict(prepared=str(output),workers=workers,preserved_rows=len(state['rows']))))


def launch(output):
    plan=verify_plan(output)
    if (output/'launch.json').exists(): raise FileExistsError('already launched; use individual resume commands')
    records=[]
    env=dict(os.environ,**THREAD_ENV)
    for s in plan['shards']:
        folder=Path(s['output'])
        assert sha(folder/'manifest.json')==s['manifest_sha256']
        cmd=[str(WORK/'.venv/bin/python'),'-u','-m','persistent_uav.cli','baselines',
             '--frozen',plan['frozen'],'--calibration-compatibility',plan['compatibility'],
             '--output',str(folder),'--split','validation','--regimes',','.join(map(str,s['regimes'])),
             '--checkpoint-policy-steps','100','--resume']
        logfile=output/f"worker_{s['worker']:02d}.log"
        with logfile.open('xb') as f:
            process=subprocess.Popen(cmd,cwd=PROJECT,env=env,stdin=subprocess.DEVNULL,
                                     stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
        records.append(dict(worker=s['worker'],pid=process.pid,command=cmd,log=str(logfile),started_unix=time.time()))
        write_json(output/'launch.json',dict(workers=records,environment=THREAD_ENV))
    print(json.dumps(records))


def collect(output):
    plan=verify_plan(output);rows=[]
    for s in plan['shards']:
        folder=Path(s['output'])
        with exclusive_run(folder):
            assert sha(folder/'manifest.json')==s['manifest_sha256']
            status=json.loads((folder/'status.json').read_text())
            if status['status']!='complete': raise ValueError('all workers must be complete before aggregation')
            state=restore(folder)
            assert state['contract']==json.loads((folder/'manifest.json').read_text())
            result=json.loads((folder/'results.json').read_text())
            assert state['rows']==result
            rows.extend(checked_rows(state['contract']['jobs'],result))
    ordered=checked_rows(plan['source_contract']['jobs'],rows)
    target=output/'aggregate'
    if target.exists(): raise FileExistsError('aggregate exists')
    target.mkdir()
    write_json(target/'results.json',ordered)
    write_json(target/'summary.json',aggregate(ordered))
    write_json(target/'thresholds.json',dict(calibration_sha256=plan['source_contract']['calibration_sha256'],
        validation_seeds=list(VALIDATION_SEEDS),selected=choose_thresholds(ordered,list(range(27))),
        caution='Empirical validation budget only, not a safety guarantee. Null means no admissible threshold.'))
    write_json(target/'integrity.json',dict(passed=True,unique_jobs=len(ordered),missing_jobs=0,
        duplicate_jobs=0,old_x86_rows_imported=0,sharding_manifest_sha256=sha(output/'sharding_manifest.json')))
    print('Aggregated exactly 1080 ARM validation rows; no evaluation launched.')


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('action',choices=['prepare','launch','collect'])
    parser.add_argument('--output',type=Path,required=True);parser.add_argument('--source',type=Path)
    parser.add_argument('--workers',type=int,default=8);args=parser.parse_args()
    if args.action=='prepare': prepare(args.source,args.output,args.workers)
    elif args.action=='launch': launch(args.output)
    else: collect(args.output)
