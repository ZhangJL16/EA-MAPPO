# CPU parallel B4 validation

8 independent CPU processes, one thread each; neither NPU is used. All eight startup checkpoints passed checksum, deserialization, current provenance, job-prefix, finite observation and thread-count checks. Five focused partition/aggregation tests passed; single-thread continuing smoke passed with full recovery outcome equality.

Original sequential run is paused and retained unchanged: 28 ARM results and its in-flight environment were migrated. No original-server x86 rows or checkpoint were imported. Do not resume the old sequential run, or double-count its 28 rows alongside the parallel output.

Output: `/mnt/workspace/persistent-uav/repo/persistent_uav_throughput_v1/artifacts/diagnostic_validation_arm64_parallel8_20260920`

Partition: regime ID modulo 8. Workers 0–2 have 160 jobs each; workers 3–7 have 120 each. The union is exactly the original 1080 jobs, with no overlaps. Worker 0 owns the preserved in-flight trajectory. Seeds, thresholds, calibration, model, native solver and runtime source are unchanged. Scientific provenance checks were not disabled. sharding_manifest.json records source snapshot, original/new contracts, orchestration hash, native hash and thread environment. Total policy-step counters preserve the old global count exactly once in worker 0.

Original compatibility remains valid because runtime source is unchanged. The explicit sharding migration record supplements it. Scripts and records are outside Git and must be retained with this workspace.

PIDs: 474437, 474438, 474439, 474440, 474441, 474442, 474443, 474444. Commands and per-worker logs are in the output launch.json; per-worker manifest/status/resume files are in worker_00 through worker_07.

Short startup sample: 770.8 policy steps/s across workers versus the earlier sequential 59.1 steps/s (about 13.0×). Different regime costs and shard imbalance prevent treating this as a guaranteed completion-time speedup.

To pause, first verify each PID command matches launch.json, then send SIGTERM to those verified worker PIDs. They save at a step boundary. For resumption after stopping, use the individual single-line commands in resume_commands.txt (one terminal per worker, or a separately audited launcher); never launch a second writer against an active worker. Original sequential launch remains paused.

Aggregation is manual after every worker is complete; it checks each final checkpoint/manifest and rejects missing, duplicate or unexpected job IDs. It does not launch evaluation:

```bash
/mnt/workspace/persistent-uav/.venv/bin/python /mnt/workspace/persistent-uav/migration_20260920/parallel/parallel_validation.py collect --output /mnt/workspace/persistent-uav/repo/persistent_uav_throughput_v1/artifacts/diagnostic_validation_arm64_parallel8_20260920
```

No further monitoring, automatic evaluation, training, MPC/Oracle, new calibration or additional runs. Completed worker thresholds are shard artifacts; use only the checked combined aggregate for the full validation result.
