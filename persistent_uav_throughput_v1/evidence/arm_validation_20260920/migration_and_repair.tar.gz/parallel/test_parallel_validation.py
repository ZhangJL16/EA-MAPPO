import copy
import unittest
from parallel_validation import partition, checked_rows, expected_jobs, key

class ShardingTests(unittest.TestCase):
    def state(self,n=382,active=True):
        jobs=expected_jobs()
        return dict(contract=dict(jobs=jobs,split='validation',regimes=list(range(27))),
                    rows=[dict(j,completed=2) for j in jobs[:n]],
                    env=object() if active else None,total_policy_steps=12345)

    def test_disjoint_complete_jobs_and_rows(self):
        state=self.state();shards=partition(state,8)
        jobs=[key(j) for s in shards for j in s['contract']['jobs']]
        self.assertEqual(len(jobs),1080);self.assertEqual(len(set(jobs)),1080)
        rows=[r for s in shards for r in s['rows']]
        self.assertEqual(len(rows),382)
        self.assertEqual({key(r) for r in rows},{key(r) for r in state['rows']})
        self.assertEqual(sum(s['total_policy_steps'] for s in shards),12345)

    def test_active_trajectory_has_exactly_one_owner_and_next_job(self):
        state=self.state();shards=partition(state,8)
        owners=[s for s in shards if s['env'] is not None]
        self.assertEqual(len(owners),1);owner=owners[0]
        self.assertIs(owner['env'],state['env'])
        self.assertEqual(owner['contract']['jobs'][len(owner['rows'])],state['contract']['jobs'][382])

    def test_initial_and_complete_and_boundary_states(self):
        for n in (0,28,40,1080):
            for count in (1,8,27):
                state=self.state(n,False);shards=partition(state,count)
                self.assertEqual(sum(len(s['rows']) for s in shards),n)
                self.assertTrue(all(s['env'] is None for s in shards))
                self.assertEqual(sum(s['total_policy_steps'] for s in shards),12345)

    def test_reject_corrupt_prefix_contract_and_worker_count(self):
        state=self.state();state['rows'][0]['seed']=-1
        with self.assertRaises(ValueError):partition(state,8)
        state=self.state();state['contract']['jobs'].pop()
        with self.assertRaises(ValueError):partition(state,8)
        for count in (0,28):
            with self.assertRaises(ValueError):partition(self.state(),count)

    def test_aggregation_requires_exactly_all_unique_jobs_and_restores_order(self):
        jobs=expected_jobs();rows=[dict(j,completed=0) for j in jobs]
        self.assertEqual(checked_rows(jobs,list(reversed(rows))),rows)
        for broken in (rows[:-1],rows+[rows[0]],rows[:-1]+[rows[0]]):
            with self.assertRaises(ValueError):checked_rows(jobs,broken)
        wrong=copy.deepcopy(rows);wrong[0]['seed']=-1
        with self.assertRaises(ValueError):checked_rows(jobs,wrong)

if __name__=='__main__':unittest.main()
