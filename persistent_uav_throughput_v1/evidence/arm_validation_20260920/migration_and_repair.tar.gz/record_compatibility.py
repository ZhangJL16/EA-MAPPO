"""Record verified relocation/CPU build compatibility without changing history."""
import copy
import json
import os
from pathlib import Path
import sys

WORK = Path(__file__).resolve().parent.parent
ROOT = WORK / 'repo'
PROJECT = ROOT / 'persistent_uav_throughput_v1'
OUT = WORK / 'migration_20260920'
os.environ['PERSISTENT_UAV_LEGACY_ROOT'] = str(ROOT)
sys.path.insert(0, str(PROJECT))
from persistent_uav.provenance import provenance, verify_provenance
from persistent_uav.storage import sha
from persistent_uav.evaluation import calibration_compatibility
from review_bundle.safety.collision.hocbf import _NATIVE_QP_FUNCTION

prior_path = PROJECT / 'evidence/v1_3/calibration_compatibility.json'
prior = json.loads(prior_path.read_text())
frozen_path = PROJECT / 'evidence/v1_2/calibration/frozen_regimes.json'
frozen = json.loads(frozen_path.read_text())
record = json.loads((OUT / 'migration.json').read_text())
for name, digest in record['historical_evidence_hashes'].items():
    assert sha(PROJECT / name) == digest, name
current = provenance()
old = prior['diagnostic_provenance']
relocated = {str(ROOT / Path(name).relative_to('/home/zjl/mappo')): digest
             for name, digest in old['sources'].items()}
assert relocated == current['sources']
assert current['checkpoint_sha256'] == old['checkpoint_sha256']
assert current['checkpoint'] == str(ROOT / Path(old['checkpoint']).relative_to('/home/zjl/mappo'))
expected_packages = dict(old['packages'], torch='2.7.1+cpu')
assert current['packages'] == expected_packages
assert old['packages']['torch'] == '2.7.1+cu128'
assert current['training_updates'] == 0 and current['optimizer_loaded'] is False
assert _NATIVE_QP_FUNCTION is not None
native = ROOT / 'runtime_support/review_bundle/safety/collision/_qp_native.so'
assert sha(native) == record['native']['arm64_binary_sha256']
assets = json.loads((PROJECT / 'evidence/v1_2/runtime_assets.json').read_text())
assert sha(WORK / 'runtime_assets.tar.gz') == assets['archive_sha256']
assert sha(ROOT / assets['assets'][1]['path']) == assets['assets'][1]['sha256']
assert prior['calibration_sha256'] == sha(frozen_path)
assert prior['calibration_provenance'] == frozen['provenance']
smoke = json.loads((OUT / 'continuing_smoke/recovery_equivalence.json').read_text())
assert smoke['passed'] and smoke['restored_outcome_equal']
assert 'Ran 29 tests' in (OUT / 'tests_with_assets.txt').read_text()
assert (OUT / 'tests_with_assets.txt').read_text().rstrip().endswith('OK')
compat = dict(reason='Explicit x86_64 to aarch64 relocation and CUDA to CPU torch build migration; unchanged Python/C source and frozen SAC; retain prior dock-idle compatibility.',
              calibration_sha256=sha(frozen_path), calibration_provenance=frozen['provenance'],
              diagnostic_provenance=current,
              historical_compatibility={'path':str(prior_path),'sha256':sha(prior_path)},
              path_mapping={'from':'/home/zjl/mappo','to':str(ROOT)},
              original_packages=old['packages'], current_packages=current['packages'],
              native=record['native'],
              checks={'all_104_python_sources_match':True,'model_hash_match':True,'native_source_hash_match':True,'historical_evidence_unchanged':True,'tests_29_passed':True,'continuing_smoke_passed':True},
              calibration_rerun=False, regimes_retuned=False,
              limits='Fresh output directories only; no historical checkpoint resume. Cross-platform bitwise equality is not established. Diagnostics remain on hold pending allocation with original-server B4 validation; no automatic next stage.')
compat_path = OUT / 'calibration_compatibility_arm64.json'
compat_path.write_text(json.dumps(compat,indent=2)+'\n')
assert calibration_compatibility(frozen_path, frozen, compat_path) == compat
# Existing strict checker must still reject the unadapted historical provenance.
try:
    verify_provenance(old)
except RuntimeError:
    pass
else:
    raise AssertionError('Historical provenance unexpectedly accepted')
record.update(status='migration_complete_diagnostics_not_started',compatibility_approved=True,
              compatibility_scope='Fresh runs using unchanged frozen calibration; no historical checkpoint migration',
              current_provenance=current,compatibility_record={'path':str(compat_path),'sha256':sha(compat_path)},
              tests={'total':29,'passed':29,'errors':0,'log':'tests_with_assets.txt'},
              continuing_smoke=smoke,provenance_checks={'new_record_accepted':True,'old_record_rejected':True})
record['runtime_archive']['verified']=True
record['model']['verified']=True
(OUT / 'migration_completed.json').write_text(json.dumps(record,indent=2)+'\n')
print('Migration verified; compatibility accepted; historical provenance still rejected.')
