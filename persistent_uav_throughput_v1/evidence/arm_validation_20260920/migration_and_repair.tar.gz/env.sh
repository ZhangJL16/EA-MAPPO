export PERSISTENT_UAV_LEGACY_ROOT=/mnt/workspace/persistent-uav/repo
export PATH=/mnt/workspace/persistent-uav/.venv/bin:$PATH
export CUDA_VISIBLE_DEVICES=''
