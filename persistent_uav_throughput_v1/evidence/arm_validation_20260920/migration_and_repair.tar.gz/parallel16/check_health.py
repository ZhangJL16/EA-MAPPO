"""Bounded startup health inspection; never waits for validation completion."""
import json,os,pickle,time
from pathlib import Path
import sys
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE.parent/'parallel'))
from parallel_validation import verify_plan, sha, key, write_json, THREAD_ENV, PROJECT
from persistent_uav.provenance import verify_provenance
from review_bundle.safety.collision.hocbf import _NATIVE_QP_FUNCTION
output=PROJECT/'artifacts/diagnostic_validation_arm64_parallel16_20260920'
plan=verify_plan(output);launch=json.loads((output/'launch.json').read_text())
assert len(launch['workers'])==plan['workers']==16
assert _NATIVE_QP_FUNCTION is not None
start=time.time();checks=[]
for _ in range(90):
    checks=[];ready=True
    for shard,process in zip(plan['shards'],launch['workers']):
        folder=Path(shard['output']);pid=process['pid']
        assert not (folder/'error.json').exists(),str(folder/'error.json')
        cmd=[v.decode() for v in Path(f'/proc/{pid}/cmdline').read_bytes().split(b'\0') if v]
        assert cmd==process['command']
        environ=dict(v.decode().split('=',1) for v in Path(f'/proc/{pid}/environ').read_bytes().split(b'\0') if b'=' in v)
        assert all(environ[k]==v for k,v in THREAD_ENV.items())
        status=json.loads((folder/'status.json').read_text())
        if status['status']!='running' or status['total_policy_steps']-shard['initial_steps']<100:
            ready=False;continue
        ref=status['snapshot'];raw=(folder/ref['file']).read_bytes()
        import hashlib
        assert hashlib.sha256(raw).hexdigest()==ref['sha256']
        state=pickle.loads(raw);manifest=json.loads((folder/'manifest.json').read_text())
        assert sha(folder/'manifest.json')==shard['manifest_sha256']
        assert state['contract']==manifest
        verify_provenance(manifest['provenance'])
        assert [key(r) for r in state['rows']]==[key(j) for j in manifest['jobs'][:len(state['rows'])]]
        assert status['completed_runs']==len(state['rows'])
        assert status['total_policy_steps']==state['total_policy_steps']
        assert state['total_policy_steps']>shard['initial_steps']
        assert status['training_updates']==0 and manifest['oracle_calls']==0
        assert state['env'] is not None
        import numpy as np
        assert np.isfinite(state['env'].nav.observation()).all()
        proc_status=Path(f'/proc/{pid}/status').read_text()
        threads=int(next(line.split(':')[1] for line in proc_status.splitlines() if line.startswith('Threads:')))
        checks.append(dict(worker=shard['worker'],pid=pid,threads=threads,status=status,
                           new_policy_steps=state['total_policy_steps']-shard['initial_steps'],
                           checksum_valid=True,deserialized=True,contract_and_provenance_valid=True,
                           observation_finite=True,thread_environment_verified=True,
                           elapsed_seconds=time.time()-process['started_unix']))
    if ready:break
    time.sleep(.5)
else:raise RuntimeError('Startup checkpoint deadline reached; inspect worker logs')
result=dict(passed=True,checked_unix=time.time(),workers=checks,old_x86_rows_imported=0,
            preserved_arm_rows=plan['source_completed_rows'],native_loaded=True,
            aggregate_new_policy_steps=sum(c['new_policy_steps'] for c in checks),
            aggregate_steps_per_second=sum(c['new_policy_steps']/c['elapsed_seconds'] for c in checks),
            note='One bounded startup check, includes process/model initialization; no completion monitoring.')
write_json(HERE/'startup_health.json',result)
print(json.dumps(result))
