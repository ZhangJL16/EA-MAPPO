import unittest
from reshard import base,split_states

class ReshardTests(unittest.TestCase):
    def fixture(self):
        full=dict(jobs=base.expected_jobs(),regimes=list(range(27)),split='validation')
        initial=dict(contract=full,rows=[],env=None,total_policy_steps=0)
        states=base.partition(initial,8)
        for i,s in enumerate(states):
            n=25+i*4
            s['rows']=[dict(j,completed=3) for j in s['contract']['jobs'][:n]]
            s['env']=object();s['total_policy_steps']=1000*(i+1)
        return states,full

    def test_preserves_eight_active_jobs_and_completed_rows(self):
        states,full=self.fixture();shards=split_states(states,full)
        self.assertEqual(len(shards),16)
        self.assertEqual(sum(s['env'] is not None for s in shards),8)
        self.assertEqual(sum(len(s['rows']) for s in shards),sum(len(s['rows']) for s in states))
        self.assertEqual(sum(s['total_policy_steps'] for s in shards),36000)
        for s in states:
            job=s['contract']['jobs'][len(s['rows'])];new=shards[job['regime']%16]
            self.assertIs(new['env'],s['env'])
            self.assertEqual(new['contract']['jobs'][len(new['rows'])],job)
        ids=[base.key(j) for s in shards for j in s['contract']['jobs']]
        self.assertEqual(len(ids),1080);self.assertEqual(len(set(ids)),1080)

    def test_complete_and_between_job_sources(self):
        states,full=self.fixture()
        for s in states:
            s['env']=None;s['rows']=[dict(j,completed=3) for j in s['contract']['jobs']]
        shards=split_states(states,full)
        self.assertEqual(sum(len(s['rows']) for s in shards),1080)
        self.assertTrue(all(s['env'] is None for s in shards))

    def test_rejects_duplicate_or_missing_source_jobs(self):
        states,full=self.fixture()
        with self.assertRaises(ValueError):split_states(states+states[:1],full)
        with self.assertRaises(ValueError):split_states(states[:-1],full)

    def test_rejects_bad_prefix(self):
        states,full=self.fixture();states[2]['rows'][0]['seed']=-1
        with self.assertRaises(ValueError):split_states(states,full)

if __name__=='__main__':unittest.main()
