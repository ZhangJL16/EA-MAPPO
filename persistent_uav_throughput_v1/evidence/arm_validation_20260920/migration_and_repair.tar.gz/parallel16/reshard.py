"""Split eight paused regime-modulo shards into sixteen; retain active states."""
from contextlib import ExitStack
import copy
import json
from pathlib import Path
import shutil
import sys
import time
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE.parent/'parallel'))
import parallel_validation as base
from persistent_uav.storage import exclusive_run, restore, sha, snapshot, write_json
from persistent_uav.provenance import verify_provenance


def split_states(states, full_contract):
    if full_contract['jobs']!=base.expected_jobs():raise ValueError('unexpected full job set')
    lookup={};active={};counters={};all_jobs=[]
    for state in states:
        contract=state['contract'];rows=state['rows'];jobs=contract['jobs']
        if [base.key(r) for r in rows]!=[base.key(j) for j in jobs[:len(rows)]]:
            raise ValueError('invalid source prefix')
        all_jobs.extend(jobs)
        for r in rows:
            k=base.key(r)
            if k in lookup:raise ValueError('duplicate source row')
            lookup[k]=r
        if state['env'] is not None:
            if len(rows)>=len(jobs):raise ValueError('active environment after last job')
            job=jobs[len(rows)];owner=job['regime']%16
            if owner in active:raise ValueError('multiple active states for one destination')
            active[owner]=(job,state['env'])
        else:
            owner=contract['regimes'][0]%16
        counters[owner]=counters.get(owner,0)+state['total_policy_steps']
    if sorted(map(base.key,all_jobs))!=sorted(map(base.key,full_contract['jobs'])):
        raise ValueError('source shards not an exact job cover')
    result=[]
    for i in range(16):
        contract=copy.deepcopy(full_contract)
        contract['regimes']=list(range(i,27,16))
        contract['jobs']=[j for j in full_contract['jobs'] if j['regime'] in contract['regimes']]
        rows=[lookup[base.key(j)] for j in contract['jobs'] if base.key(j) in lookup]
        if [base.key(r) for r in rows]!=[base.key(j) for j in contract['jobs'][:len(rows)]]:
            raise ValueError('destination rows not prefix')
        env=None
        if i in active:
            job,env=active[i]
            if contract['jobs'][len(rows)]!=job:raise ValueError('active trajectory would change job')
        result.append(dict(contract=contract,rows=rows,env=env,total_policy_steps=counters.get(i,0)))
    assert sum(len(s['rows']) for s in result)==len(lookup)
    assert sum(s['env'] is not None for s in result)==len(active)
    assert sum(s['total_policy_steps'] for s in result)==sum(s['total_policy_steps'] for s in states)
    return result


def prepare():
    source=base.PROJECT/'artifacts/diagnostic_validation_arm64_parallel8_20260920'
    output=base.PROJECT/'artifacts/diagnostic_validation_arm64_parallel16_20260920'
    if output.exists():raise FileExistsError(output)
    previous=base.verify_plan(source)
    states=[];artifacts={};source_refs=[]
    with ExitStack() as locks:
        for shard in previous['shards']:
            folder=Path(shard['output']);locks.enter_context(exclusive_run(folder))
            assert sha(folder/'manifest.json')==shard['manifest_sha256']
            status=json.loads((folder/'status.json').read_text());assert status['status'] in ('paused','complete')
            state=restore(folder);assert state['contract']==json.loads((folder/'manifest.json').read_text())
            verify_provenance(state['contract']['provenance'])
            assert len(state['rows'])==status['completed_runs']
            assert state['total_policy_steps']==status['total_policy_steps']
            states.append(state)
            source_refs.append(dict(output=str(folder),resume=json.loads((folder/'resume.json').read_text()),status=status))
            for n,row in enumerate(state['rows']):
                f=folder/f'run_{n:05d}.json';assert json.loads(f.read_text())['summary']==row
                artifacts[base.key(row)]=f
        shards=split_states(states,previous['source_contract'])
        output.mkdir()
        plan={k:copy.deepcopy(v) for k,v in previous.items() if k not in ('shards','source_resume','source_manifest_sha256')}
        plan.update(workers=16,source=str(source),source_completed_rows=sum(len(s['rows']) for s in states),
            source_policy_steps=sum(s['total_policy_steps'] for s in states),
            prior_sharding_manifest_sha256=sha(source/'sharding_manifest.json'),source_worker_snapshots=source_refs,
            reshard_script_sha256=sha(Path(__file__)),policy='regime ID modulo 16; exact 1080-job union; all eight in-flight states retain ownership',
            created_unix=time.time(),shards=[])
        for i,state in enumerate(shards):
            folder=output/f'worker_{i:02d}';folder.mkdir()
            write_json(folder/'manifest.json',state['contract']);ref=snapshot(folder,state)
            write_json(folder/'status.json',dict(status='paused',completed_runs=len(state['rows']),
                planned_runs=len(state['contract']['jobs']),total_policy_steps=state['total_policy_steps'],snapshot=ref,
                checkpoint_written_unix=time.time(),training_updates=0))
            for n,row in enumerate(state['rows']):shutil.copy2(artifacts[base.key(row)],folder/f'run_{n:05d}.json')
            for old in previous['shards']:
                for f in Path(old['output']).glob('stream_*.json'):
                    if int(f.name.split('_')[1][1:]) in state['contract']['regimes']:shutil.copy2(f,folder/f.name)
            restored=restore(folder)
            assert restored['rows']==state['rows'] and restored['contract']==state['contract']
            if state['env'] is not None:
                assert restored['env'].observe()==state['env'].observe()
                assert restored['env'].summary()==state['env'].summary()
                assert restored['env'].events==state['env'].events
            plan['shards'].append(dict(worker=i,output=str(folder),regimes=state['contract']['regimes'],
                jobs=len(state['contract']['jobs']),initial_rows=len(state['rows']),initial_steps=state['total_policy_steps'],
                carries_live_environment=state['env'] is not None,manifest_sha256=sha(folder/'manifest.json'),initial_snapshot=ref))
        write_json(output/'sharding_manifest.json',plan)
        for ref in source_refs:assert json.loads((Path(ref['output'])/'resume.json').read_text())==ref['resume']
        base.verify_plan(output)
        check=dict(passed=True,workers=16,source_workers_unchanged=True,preserved_arm_rows=plan['source_completed_rows'],
            preserved_active_trajectories=sum(s['env'] is not None for s in shards),exact_job_union=1080,
            duplicate_jobs=0,missing_jobs=0,serialized_states_verified=True,old_x86_rows_imported=0)
        write_json(HERE/'migration_check.json',check);print(json.dumps(check))

if __name__=='__main__':prepare()
