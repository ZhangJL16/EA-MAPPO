# 16-worker CPU validation handoff

Expanded at user request from 8 to 16 independent CPU workers, one actual thread each. Neither NPU is used. All 16 startup checkpoints passed checksum, deserialization, contract/provenance, finite observation, process identity and thread-environment checks. Four focused resharding tests passed. Physics/model/runtime code and thread configuration are unchanged; the previously passing single-thread continuing smoke remains applicable.

Preserved 243 completed ARM results and all 8 in-flight trajectories. No original-server x86 results were imported. The original sequential and 8-worker runs remain paused, with original manifests and snapshots retained. Do not resume them or double-count their rows. Only this 16-worker tree is active.

Output: `/mnt/workspace/persistent-uav/repo/persistent_uav_throughput_v1/artifacts/diagnostic_validation_arm64_parallel16_20260920`

Regime ID modulo 16 assigns each of the original 1080 jobs exactly once. Workers 0–10 have 80 planned jobs each; workers 11–15 have 40 each. Active environments and completed rows retain their exact matching job IDs; source policy-step bookkeeping is preserved exactly once. No seeds, thresholds, calibration, 27 regimes, collision rules or observation contracts changed.

Migration: reshard.py and migration_check.json. Four test results: tests.txt. Immutable orchestration and source checks: sharding_manifest.json links the 8-worker plan and each paused source snapshot. Existing v1.4 compatibility is retained, and runtime provenance checks remain active. Each destination snapshot was deserialized and compared with its migrated state before launch.

PIDs: 487006, 487007, 487008, 487009, 487010, 487011, 487012, 487013, 487014, 487015, 487016, 487017, 487018, 487019, 487020, 487021. The output launch.json contains full commands; worker_00 through worker_15 each contain their own manifest, status and resume pointer, with corresponding worker logs in the parent output directory.

To pause, first verify PID commands against launch.json and send SIGTERM to those verified PIDs. To resume after stopping, use the individual one-line commands in resume_commands.txt; never start another writer against an active worker. Do not use the old 8-worker launch or resume commands.

Manual aggregation after all workers complete (rejects duplicates, missing or unexpected jobs; no automatic evaluation):

```bash
/mnt/workspace/persistent-uav/.venv/bin/python /mnt/workspace/persistent-uav/migration_20260920/parallel/parallel_validation.py collect --output /mnt/workspace/persistent-uav/repo/persistent_uav_throughput_v1/artifacts/diagnostic_validation_arm64_parallel16_20260920
```

The 16 workers continue running after this startup handoff. No monitoring to completion, automatic evaluation, training, MPC/Oracle or calibration rerun.
