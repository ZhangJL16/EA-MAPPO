# ARM64 CPU migration — 2026-09-20

Migration completed. Diagnostics have NOT been started.

- Repository: ../repo, commit a5ea2968eba42eb61fa29b44ccaa48f9d8ae2278.
- Archive and all three asset hashes match the repository asset inventory.
- All 104 Python source hashes match historical diagnostic provenance after explicit path relocation.
- Native C source unchanged; original x86_64 binary preserved as _qp_native.x86_64.so; local ARM64 build loaded successfully.
- torch changed from 2.7.1+cu128 to 2.7.1+cpu; other five-package provenance entries unchanged.
- 29 tests passed (tests_with_assets.txt).
- Continuing smoke passed: three services, one recharge, dock idle, one physical reset; full outcomes match after midflight recovery. This is an engineering fixture, not a diagnostic result.
- Historical evidence, calibration and frozen 27 regimes are unchanged. No neural training, MPC or Oracle ran.

Use `source /mnt/workspace/persistent-uav/migration_20260920/env.sh` before running from `repo/persistent_uav_throughput_v1`.

`migration.json` retains the initial incomplete migration record. `migration_completed.json` records completion. `record_compatibility.py` verifies the migration and produces `calibration_compatibility_arm64.json`; the existing application checker accepts the new record and continues to reject unadapted historical provenance. No provenance implementation was changed.

For a future authorized diagnostic, use a fresh output directory and pass `--calibration-compatibility /mnt/workspace/persistent-uav/migration_20260920/calibration_compatibility_arm64.json`. Do not resume the original server's checkpoint. Cross-platform bitwise equivalence has not been established. Before launching, explicitly allocate work relative to the original server's B4 validation to avoid duplicate counting. Check startup health and hand back; do not advance stages automatically.

Keep this directory with the repository: these server-specific migration records are outside Git. The only tracked repository change is the rebuilt native binary; the frozen model is installed as an untracked runtime asset.

## User-approved allocation and hold — 2026-09-20

This allocation supersedes the earlier unresolved diagnostic allocation above.

- Original server preserves its 382 completed results and checkpoint as historical diagnostic evidence. It owns investigation and repair of the waiting-time grid error triggered by trajectory 383, and must not resume yet.
- ARM is the unified platform for subsequent diagnostics after receiving the repair commit and verifying compatibility. Do not start B4 before that verification.
- The current 29 passing tests and continuing smoke do not cover the trajectory-383 failure. Migration success is not validation of that defect's repair.
- After the repair arrives, verify the fix against the reported failure and verify source/calibration/runtime compatibility explicitly. Preserve historical manifests and append repair/migration evidence; do not bypass provenance checks.
- Then start a fresh, complete B4 validation with the original seeds, parameters and all 27 regimes: 27 × 4 thresholds × 10 seeds = 1080 runs in a new output directory. Do not import the original server's checkpoint or combine its 382 results with the ARM formal summary.
- Do not rerun the 1000-job calibration.
- Check only the first resumable checkpoint's startup health, then hand the running job back. Do not monitor to completion or automatically advance to evaluation or training. Neural training remains prohibited; MPC/Oracle remain deferred.

Current state: waiting for the repair commit; B4 has not been started on ARM.

## v1.4 launch supersedes the hold

On user instruction, synchronized 5bf3025, audited new compatibility, passed 34 tests and continuing smoke, and launched full fresh ARM B4 validation. Startup health passed; process handed back running. See [v1.4 handoff](v1_4/HANDOFF.md), launch.json and startup_health.json. Prior records remain unchanged.

## CPU parallel launch supersedes sequential execution

At user request, sequential B4 was safely paused at 28 completed ARM rows and its current trajectory. Eight single-thread CPU worker processes now own disjoint shards; startup health passed. See [parallel handoff](parallel/HANDOFF.md). Do not resume the original sequential run or count its migrated rows twice. Neither NPU is used.

## 16 CPU workers supersede the 8-worker run

Expanded on user request, preserving 243 completed ARM rows and all 8 in-flight trajectories. All 16 single-thread worker startup checkpoints passed. See [16-worker handoff](parallel16/HANDOFF.md). Prior run trees remain paused historical records; do not resume or count their rows again. Neither NPU is used.
