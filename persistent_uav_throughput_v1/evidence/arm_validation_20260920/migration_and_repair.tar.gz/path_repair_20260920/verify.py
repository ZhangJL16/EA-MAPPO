import os,sys,json,time,hashlib,pickle,statistics
from pathlib import Path
root=Path('/mnt/workspace/persistent-uav/repo');sys.path.insert(0,str(root/'persistent_uav_throughput_v1'));os.environ['PERSISTENT_UAV_LEGACY_ROOT']=str(root)
from persistent_uav.provenance import verify_provenance
p=root/'persistent_uav_throughput_v1/artifacts/diagnostic_validation_arm64_parallel16_20260920';record=Path('/mnt/workspace/zjl-exp/migration_20260920/path_repair_20260920')
first=json.loads((record/'sample1.json').read_text());checks=[];keys=[];durations={}
for w in sorted(p.glob('worker_*')):
 if not w.is_dir():continue
 for attempt in range(5):
  s=json.loads((w/'status.json').read_text())
  try:raw=(w/s['snapshot']['file']).read_bytes();break
  except FileNotFoundError:continue
 assert hashlib.sha256(raw).hexdigest()==s['snapshot']['sha256']
 state=pickle.loads(raw);manifest=json.loads((w/'manifest.json').read_text());verify_provenance(manifest['provenance']);assert state['contract']==manifest
 key=lambda x:tuple(x[k] for k in ('regime','method','threshold','seed'))
 assert [key(r) for r in state['rows']]==[key(j) for j in manifest['jobs'][:len(state['rows'])]]
 assert len(state['rows'])==s['completed_runs'];keys.extend(key(r) for r in state['rows'])
 assert not (w/'error.json').exists()
 advanced=s['total_policy_steps']>first['workers'][w.name]['total_policy_steps']
 assert s['status']=='complete' or (s['status']=='running' and advanced and time.time()-(w/'status.json').stat().st_mtime<15)
 if s['status']=='complete':
  assert len(json.loads((w/'results.json').read_text()))==s['planned_runs'];assert (w/'thresholds.json').exists()
 checks.append(dict(worker=w.name,status=s['status'],completed=s['completed_runs'],planned=s['planned_runs'],steps=s['total_policy_steps'],advanced=advanced,checksum_and_contract_valid=True))
 files=sorted(w.glob('run_*.json'))
 for a,b in zip(files,files[1:]):
  row=json.loads(b.read_text())['summary'];dt=b.stat().st_mtime-a.stat().st_mtime
  if row['regime']>=16 and w.name not in ('worker_00','worker_01'):durations.setdefault(row['threshold'],[]).append(dt)
assert len(keys)==len(set(keys))
report=dict(checked_unix=time.time(),completed=sum(c['completed'] for c in checks),planned=1080,workers=checks,mean_later_regime_seconds={str(k):statistics.mean(v) for k,v in durations.items()},unique_rows=True)
(record/'verified_health.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
