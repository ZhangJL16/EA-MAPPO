import os,json,subprocess,hashlib,time
from pathlib import Path
root=Path('/mnt/workspace/persistent-uav'); project=root/'repo/persistent_uav_throughput_v1'
import sys
sys.path.insert(0,str(project));os.environ['PERSISTENT_UAV_LEGACY_ROOT']=str(root/'repo')
from persistent_uav.provenance import verify_provenance
from persistent_uav.storage import restore
output=project/'artifacts/diagnostic_validation_arm64_parallel16_20260920'
launch=json.loads((output/'launch.json').read_text());record=Path('/mnt/workspace/zjl-exp/migration_20260920/path_repair_20260920'); resumed=[]
for w in launch['workers']:
 folder=output/f"worker_{w['worker']:02d}"
 s=json.loads((folder/'status.json').read_text())
 if s['status']!='error':continue
 proc=Path(f"/proc/{w['pid']}/cmdline")
 assert not proc.exists() or not proc.read_bytes()
 manifest=json.loads((folder/'manifest.json').read_text());verify_provenance(manifest['provenance'])
 state=restore(folder);assert state['contract']==manifest
 assert len(state['rows'])==s['completed_runs']
 (folder/'error.json').rename(record/f"worker_{w['worker']:02d}_original_error.json")
 env=os.environ.copy()
 for key in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS','VECLIB_MAXIMUM_THREADS','BLIS_NUM_THREADS'):env[key]='1'
 env.update(CUDA_VISIBLE_DEVICES='',ASCEND_RT_VISIBLE_DEVICES='')
 with open(w['log'],'ab',buffering=0) as log:
  p=subprocess.Popen(w['command'],cwd=project,env=env,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 resumed.append(dict(worker=w['worker'],pid=p.pid,command=w['command'],started_unix=time.time(),restored_runs=len(state['rows'])))
(record/'resumed.json').write_text(json.dumps(resumed,indent=2));print(json.dumps(resumed))
