# 2026-09-20 路径迁移修复与进度检查

北京时间 17:49 检查：B4 validation 990/1080 完成（91.7%）。worker 00、01、11–15 已 complete；02–10 正常推进。16 个检查点的 SHA256、反序列化、manifest/provenance、结果 job 前缀均通过，已完成结果无重复。没有修改实验代码、参数、种子、模型或校准数据。

根因：运行中将 persistent-uav 工作目录搬至 zjl-exp，进程的 cwd 与打开的日志跟随搬迁，但绝对输出路径重新创建了旧目录。新旧两处结果分裂；7 个 worker 在最终生成 thresholds.json 时因旧路径缺少 frozen_regimes.json 报错。

修复：核对进程身份后短暂 SIGSTOP 9 个活动进程；完整备份两处输出，合并旧路径下的较新状态和结果。为保持 checkpoint 记录中的绝对路径和 provenance 完全一致，仓库实体恢复为 /mnt/workspace/persistent-uav/repo，/mnt/workspace/zjl-exp/repo 为指向它的符号链接。旧路径的 .venv 与 migration_20260920 链接至当前目录相应资源。所有活动进程恢复运行。7 个失败 worker 经 provenance 与 snapshot 验证后用原命令 --resume 恢复，均已完整收尾。

repair.json 记录合并；before_current 与 before_old_repo 保存修复前数据；worker_*_original_error.json 保存原始报错；resumed.json 保存恢复进程命令及 PID。原 launch.json 保持不改，恢复 PID 应以 resumed.json 为准。verified_health.json 为修复后核验记录。

预计仍需约 1–2 小时，即北京时间 9 月 20 日 18:50–19:50；中心估计约 19:15。依据剩余最多的 worker_10 约 25 个任务，同阶段 threshold 0.25/0.5/0.75 已完成任务平均约 76/211/271 秒，估算约 86 分钟。任务长度差异较大，非保证完成时间。7 个较早失败分片的停机时间不计入此耗时样本。

保持当前实验运行；本次未启动后续 evaluation 或训练。以后不要在运行时移动仓库实体或删除兼容路径。当前目录 repo 链接可正常查看最新结果。
