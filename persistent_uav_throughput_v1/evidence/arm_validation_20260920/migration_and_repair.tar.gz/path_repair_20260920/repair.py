import os,json,signal,time,shutil,hashlib
from pathlib import Path
new=Path('/mnt/workspace/zjl-exp/repo'); old=Path('/mnt/workspace/persistent-uav/repo')
record=Path('/mnt/workspace/zjl-exp/migration_20260920/path_repair_20260920')
rel=Path('persistent_uav_throughput_v1/artifacts/diagnostic_validation_arm64_parallel16_20260920')
launch=json.loads((new/rel/'launch.json').read_text()); active=[]
for w in launch['workers']:
 p=Path(f"/proc/{w['pid']}/cmdline")
 if p.exists() and p.read_bytes():
  assert [x.decode() for x in p.read_bytes().split(b'\0') if x]==w['command']
  active.append(w['pid'])
for pid in active:os.kill(pid,signal.SIGSTOP)
try:
 for pid in active:
  for _ in range(100):
   if '\nState:\tT' in Path(f'/proc/{pid}/status').read_text():break
   time.sleep(.02)
  else:raise RuntimeError('not stopped')
 shutil.copytree(new/rel,record/'before_current')
 shutil.copytree(old,record/'before_old_repo')
 conflicts=[]; copied=[]
 for src in old.rglob('*'):
  if not src.is_file():continue
  r=src.relative_to(old); dst=new/r
  if dst.exists() and src.read_bytes()!=dst.read_bytes():
   assert src.stat().st_mtime>=dst.stat().st_mtime,(src,dst)
   assert src.name in ('status.json','resume.json') or src.suffix=='.tmp',str(src)
   conflicts.append(str(r))
  dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,dst);copied.append(str(r))
 old.rename(record/'displaced_old_repo')
 new.rename(old)
 new.symlink_to(old,target_is_directory=True)
 for name in ('.venv','migration_20260920'):
  alias=old.parent/name
  assert not alias.exists()
  alias.symlink_to(Path('/mnt/workspace/zjl-exp')/name,target_is_directory=True)
 (record/'repair.json').write_text(json.dumps(dict(time=time.time(),active_pids=active,copied=copied,replaced_latest=conflicts,canonical_repo=str(old),current_access=str(new)),indent=2))
finally:
 for pid in active:os.kill(pid,signal.SIGCONT)
print('restored paths; resumed',active)
